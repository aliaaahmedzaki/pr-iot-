def assess_risk(original, attacked, secured, attack_type):

    if attack_type == "Sniffing":

        return {
            "level":"MEDIUM",
            "score":40,
            "recommendations":[
                "Encrypt IoT data"
            ]
        }

    if attack_type == "MITM":

        return {
            "level":"LOW",
            "score":25,
            "recommendations":[
                "Tampering detected"
            ]
        }

    if attack_type == "Replay":

        return {
            "level":"LOW",
            "score":20,
            "recommendations":[
                "Replay blocked"
            ]
        }

    if attack_type == "Injection":

        return {
            "level":"LOW",
            "score":25,
            "recommendations":[
                "Input blocked"
            ]
        }

    if attack_type == "Brute Force":

        return {
            "level":"MEDIUM",
            "score":50,
            "recommendations":[
                "Rate limiting applied"
            ]
        }